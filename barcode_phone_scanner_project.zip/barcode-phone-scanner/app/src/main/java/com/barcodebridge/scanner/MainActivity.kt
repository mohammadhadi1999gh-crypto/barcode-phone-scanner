package com.barcodebridge.scanner

import android.Manifest
import android.app.AlertDialog
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.NetworkInterface
import java.net.SocketTimeoutException
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {

    private val udpPort = 8766
    private val defaultHttpPort = 8765

    private val matchParent = ViewGroup.LayoutParams.MATCH_PARENT
    private val wrapContent = ViewGroup.LayoutParams.WRAP_CONTENT
    private val colorGreen = Color.parseColor("#7CFC00")
    private val colorRed = Color.parseColor("#FF6B6B")
    private val colorOrange = Color.parseColor("#FFB74D")

    private lateinit var prefs: SharedPreferences
    private lateinit var previewView: PreviewView
    private lateinit var statusView: TextView
    private lateinit var lastView: TextView
    private lateinit var enterSwitch: Switch

    private val netExec = Executors.newSingleThreadExecutor()
    private val camExec = Executors.newSingleThreadExecutor()
    private val scanner by lazy { BarcodeScanning.getClient() }

    @Volatile private var host: String? = null
    @Volatile private var port: Int = 8765
    @Volatile private var connected = false
    @Volatile private var connecting = false
    @Volatile private var pcName = "PC"

    private var lastCode = ""
    private var lastTime = 0L
    private var dialog: AlertDialog? = null

    // ------------------------------------------------------------ lifecycle ----
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        prefs = getSharedPreferences("bridge", Context.MODE_PRIVATE)
        bindToWifi()
        buildUi()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) {
            startCamera()
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 1)
        }
        connect()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            toast("برای اسکن، اجازه‌ی دوربین لازم است")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        camExec.shutdown()
        netExec.shutdown()
        try {
            scanner.close()
        } catch (e: Exception) {
        }
    }

    // ------------------------------------------------------------------- UI ----
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val root = FrameLayout(this)

        previewView = PreviewView(this)
        root.addView(previewView, FrameLayout.LayoutParams(matchParent, matchParent))

        val top = LinearLayout(this)
        top.orientation = LinearLayout.VERTICAL
        top.setBackgroundColor(Color.argb(170, 0, 0, 0))
        top.setPadding(dp(12), dp(16), dp(12), dp(12))

        val brand = LinearLayout(this)
        brand.orientation = LinearLayout.HORIZONTAL
        brand.gravity = Gravity.CENTER
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo_mark)
        brand.addView(logo, LinearLayout.LayoutParams(dp(34), dp(34)))
        val brandText = TextView(this)
        brandText.text = "  سامانه نرم‌افزاری Hnomandan"
        brandText.textSize = 16f
        brandText.setTextColor(Color.WHITE)
        brandText.setTypeface(null, Typeface.BOLD)
        brand.addView(brandText)
        top.addView(brand)

        statusView = TextView(this)
        statusView.textSize = 18f
        statusView.setTextColor(Color.WHITE)
        statusView.gravity = Gravity.CENTER
        statusView.text = "در حال راه‌اندازی..."

        lastView = TextView(this)
        lastView.textSize = 26f
        lastView.setTextColor(colorGreen)
        lastView.gravity = Gravity.CENTER

        top.addView(statusView)
        top.addView(lastView)
        root.addView(top, FrameLayout.LayoutParams(matchParent, wrapContent, Gravity.TOP))

        val bottom = LinearLayout(this)
        bottom.orientation = LinearLayout.HORIZONTAL
        bottom.gravity = Gravity.CENTER_VERTICAL
        bottom.setBackgroundColor(Color.argb(170, 0, 0, 0))
        bottom.setPadding(dp(12), dp(8), dp(12), dp(8))

        enterSwitch = Switch(this)
        enterSwitch.text = "زدن Enter بعد از اسکن"
        enterSwitch.setTextColor(Color.WHITE)
        enterSwitch.isChecked = prefs.getBoolean("enter", true)
        enterSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("enter", checked).apply()
        }

        val menuButton = Button(this)
        menuButton.text = "تنظیمات"
        menuButton.setOnClickListener { showMenu() }

        bottom.addView(enterSwitch, LinearLayout.LayoutParams(0, wrapContent, 1f))
        bottom.addView(menuButton)
        root.addView(bottom, FrameLayout.LayoutParams(matchParent, wrapContent, Gravity.BOTTOM))

        setContentView(root)
    }

    private fun setStatus(text: String, color: Int) {
        runOnUiThread {
            statusView.text = text
            statusView.setTextColor(color)
        }
    }

    private fun toast(text: String) {
        runOnUiThread { Toast.makeText(this, text, Toast.LENGTH_LONG).show() }
    }

    private fun showMenu() {
        val items = arrayOf(
            "وارد کردن کد جفت‌سازی",
            "وارد کردن دستی آدرس کامپیوتر",
            "اتصال دوباره"
        )
        AlertDialog.Builder(this)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> askPin()
                    1 -> askAddress()
                    2 -> {
                        connected = false
                        connect()
                    }
                }
            }
            .show()
    }

    private fun askPin() {
        if (isFinishing || dialog?.isShowing == true) return
        val input = EditText(this)
        input.inputType = InputType.TYPE_CLASS_NUMBER
        input.hint = "کد ۶ رقمی روی کامپیوتر"
        input.setText(pin())
        dialog = AlertDialog.Builder(this)
            .setTitle("جفت‌سازی با کامپیوتر")
            .setMessage("کدی که برنامه‌ی ویندوز نشان می‌دهد را وارد کنید (فقط یک بار).")
            .setView(input)
            .setPositiveButton("تایید") { _, _ ->
                prefs.edit().putString("pin", input.text.toString().trim()).apply()
                connected = false
                connect()
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun askAddress() {
        if (isFinishing || dialog?.isShowing == true) return
        val input = EditText(this)
        input.hint = "مثلاً 192.168.1.20"
        input.setText(prefs.getString("host", "") ?: "")
        dialog = AlertDialog.Builder(this)
            .setTitle("آدرس کامپیوتر")
            .setView(input)
            .setPositiveButton("تایید") { _, _ ->
                val text = input.text.toString().trim()
                if (text.isNotEmpty()) {
                    prefs.edit().putString("host", text).putInt("port", defaultHttpPort).apply()
                }
                connected = false
                connect()
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    // --------------------------------------------------------------- camera ----
    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                val preview = Preview.Builder().build()
                preview.setSurfaceProvider(previewView.surfaceProvider)

                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                analysis.setAnalyzer(camExec) { proxy -> analyze(proxy) }

                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
            } catch (e: Exception) {
                setStatus("خطا در راه‌اندازی دوربین", colorRed)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyze(proxy: ImageProxy) {
        val media = proxy.image
        if (media == null) {
            proxy.close()
            return
        }
        val image = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
        scanner.process(image)
            .addOnSuccessListener { list ->
                val value = list.firstOrNull()?.rawValue
                if (value != null) onCode(value)
            }
            .addOnCompleteListener { proxy.close() }
    }

    private fun onCode(code: String) {
        val now = System.currentTimeMillis()
        if (code == lastCode && now - lastTime < 2500) return
        lastCode = code
        lastTime = now
        vibrate()
        runOnUiThread { lastView.text = code }
        sendCode(code)
    }

    @Suppress("DEPRECATION")
    private fun vibrate() {
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(VibrationEffect.createOneShot(70, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                v.vibrate(70)
            }
        } catch (e: Exception) {
        }
    }

    // -------------------------------------------------------------- network ----
    private fun pin(): String = prefs.getString("pin", "") ?: ""

    /** Make sure traffic to the PC goes over Wi-Fi even if the Wi-Fi has no internet. */
    @Suppress("DEPRECATION")
    private fun bindToWifi() {
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            for (n in cm.allNetworks) {
                val caps = cm.getNetworkCapabilities(n) ?: continue
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                    cm.bindProcessToNetwork(n)
                    return
                }
            }
        } catch (e: Exception) {
        }
    }

    private fun httpGetText(url: String): Pair<Int, String> {
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 1500
            c.readTimeout = 2500
            c.requestMethod = "GET"
            try {
                val code = c.responseCode
                val stream = if (code in 200..299) c.inputStream else c.errorStream
                val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
                Pair(code, text)
            } finally {
                c.disconnect()
            }
        } catch (e: Exception) {
            Pair(-1, "")
        }
    }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    private fun sendCode(code: String) {
        val h = host
        if (!connected || h == null) {
            setStatus("به کامپیوتر وصل نیست؛ در حال اتصال...", colorOrange)
            connect()
            return
        }
        val enter = if (enterSwitch.isChecked) "1" else "0"
        val p = port
        val pinValue = pin()
        netExec.execute {
            val url = "http://$h:$p/scan?pin=${enc(pinValue)}&c=${enc(code)}&e=$enter"
            val (status, _) = httpGetText(url)
            when (status) {
                200 -> setStatus("ارسال شد ✓  ($pcName)", colorGreen)
                403 -> {
                    connected = false
                    setStatus("کد جفت‌سازی اشتباه است", colorRed)
                    runOnUiThread { askPin() }
                }
                else -> {
                    connected = false
                    setStatus("ارسال نشد؛ در حال اتصال دوباره...", colorOrange)
                    connect()
                }
            }
        }
    }

    private fun connect() {
        if (connecting) return
        connecting = true
        netExec.execute {
            try {
                doConnect()
            } finally {
                connecting = false
            }
        }
    }

    private fun doConnect() {
        if (pin().isEmpty()) {
            setStatus("کد جفت‌سازی را وارد کنید", colorOrange)
            runOnUiThread { askPin() }
            return
        }
        setStatus("در حال جستجوی کامپیوتر...", Color.WHITE)

        val savedHost = prefs.getString("host", null)
        if (savedHost != null && tryHost(savedHost, prefs.getInt("port", defaultHttpPort))) return

        for (attempt in 1..4) {
            val found = discover()
            if (found != null && tryHost(found.first, found.second)) return
        }
        setStatus(
            "کامپیوتر پیدا نشد. برنامه‌ی ویندوز باز است و هر دو روی یک وای‌فای هستند؟",
            colorRed
        )
    }

    /** Returns true when the search can stop (connected, or the pairing code was rejected). */
    private fun tryHost(h: String, p: Int): Boolean {
        val (status, body) = httpGetText("http://$h:$p/ping?pin=${enc(pin())}")
        return when (status) {
            200 -> {
                host = h
                port = p
                connected = true
                pcName = body.substringAfter("ok|", "PC").trim()
                prefs.edit().putString("host", h).putInt("port", p).apply()
                setStatus("متصل شد: $pcName ✓", colorGreen)
                true
            }
            403 -> {
                connected = false
                setStatus("کد جفت‌سازی اشتباه است", colorRed)
                runOnUiThread { askPin() }
                true
            }
            else -> false
        }
    }

    /** Broadcasts a discovery packet on the local network and waits for the PC to answer. */
    private fun discover(): Pair<String, Int>? {
        var socket: DatagramSocket? = null
        try {
            socket = DatagramSocket()
            socket.broadcast = true
            socket.soTimeout = 700

            val message = "BARCODE_BRIDGE_DISCOVER".toByteArray()
            val targets = LinkedHashSet<InetAddress>()
            targets.add(InetAddress.getByName("255.255.255.255"))
            val interfaces = NetworkInterface.getNetworkInterfaces()
            if (interfaces != null) {
                for (ni in interfaces.toList()) {
                    if (!ni.isUp || ni.isLoopback) continue
                    for (ia in ni.interfaceAddresses) {
                        val b = ia.broadcast
                        if (b != null) targets.add(b)
                    }
                }
            }
            for (t in targets) {
                try {
                    socket.send(DatagramPacket(message, message.size, t, udpPort))
                } catch (e: Exception) {
                }
            }

            val buffer = ByteArray(256)
            val end = System.currentTimeMillis() + 1500
            while (System.currentTimeMillis() < end) {
                try {
                    val packet = DatagramPacket(buffer, buffer.size)
                    socket.receive(packet)
                    val text = String(packet.data, 0, packet.length, Charsets.UTF_8)
                    if (text.startsWith("BARCODE_BRIDGE_HERE")) {
                        val parts = text.split("|")
                        val p = parts.getOrNull(1)?.toIntOrNull() ?: defaultHttpPort
                        val address = packet.address.hostAddress
                        if (address != null) return Pair(address, p)
                    }
                } catch (e: SocketTimeoutException) {
                    // keep waiting until the deadline
                }
            }
        } catch (e: Exception) {
            // ignore and report "not found"
        } finally {
            socket?.close()
        }
        return null
    }
}
