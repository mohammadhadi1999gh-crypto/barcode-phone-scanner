@echo off
title Barcode Bridge - Install
set "APP=C:\BarcodeBridge"

rem --- ask for administrator permission (needed once, for the firewall) ---
if "%~1"=="elevated" goto :main
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -ArgumentList 'elevated' -Verb RunAs"
exit /b

:main
cd /d "%~dp0"
echo Installing Barcode Bridge to %APP% ...

taskkill /f /im BarcodeBridge.exe >nul 2>&1
if not exist "%APP%" mkdir "%APP%"
copy /y BarcodeBridge.cs "%APP%\BarcodeBridge.cs" >nul
if errorlevel 1 (
  echo Could not copy files. Make sure you extracted the zip first.
  pause
  exit /b 1
)

rem --- build the program using the compiler built into Windows ---
set "CSC="
for %%D in (v4.0.30319 v3.5 v2.0.50727) do if exist "%windir%\Microsoft.NET\Framework\%%D\csc.exe" if not defined CSC set "CSC=%windir%\Microsoft.NET\Framework\%%D\csc.exe"
if not defined CSC (
  echo .NET Framework compiler was not found on this PC.
  pause
  exit /b 1
)
if exist "%APP%\BarcodeBridge.exe" del /f /q "%APP%\BarcodeBridge.exe"
"%CSC%" /nologo /target:exe /r:System.dll /out:"%APP%\BarcodeBridge.exe" "%APP%\BarcodeBridge.cs"
if errorlevel 1 (
  echo Build failed. Please send the message above to the developer.
  pause
  exit /b 1
)

rem --- allow normal users to run/write in the folder, open the web port, open the firewall ---
icacls "%APP%" /grant "*S-1-5-32-545:(OI)(CI)M" /T >nul
netsh http delete urlacl url=http://+:8765/ >nul 2>&1
netsh http add urlacl url=http://+:8765/ sddl=D:(A;;GX;;;WD) >nul
netsh advfirewall firewall delete rule name="Barcode Bridge TCP" >nul 2>&1
netsh advfirewall firewall delete rule name="Barcode Bridge UDP" >nul 2>&1
netsh advfirewall firewall add rule name="Barcode Bridge TCP" dir=in action=allow protocol=TCP localport=8765 profile=any >nul
netsh advfirewall firewall add rule name="Barcode Bridge UDP" dir=in action=allow protocol=UDP localport=8766 profile=any >nul

rem --- start automatically when Windows starts, and add a desktop shortcut ---
powershell -NoProfile -ExecutionPolicy Bypass -Command "$w=New-Object -ComObject WScript.Shell; $s=$w.CreateShortcut($env:ProgramData+'\Microsoft\Windows\Start Menu\Programs\Startup\Barcode Bridge.lnk'); $s.TargetPath='C:\BarcodeBridge\BarcodeBridge.exe'; $s.WorkingDirectory='C:\BarcodeBridge'; $s.WindowStyle=7; $s.Save(); $d=$w.CreateShortcut($env:PUBLIC+'\Desktop\Barcode Bridge.lnk'); $d.TargetPath='C:\BarcodeBridge\BarcodeBridge.exe'; $d.WorkingDirectory='C:\BarcodeBridge'; $d.Save()"

cd /d "%APP%"
start "" "%APP%\BarcodeBridge.exe"

echo.
echo Done. The bridge is running now and will start automatically with Windows.
echo Look at the black window: it shows the 6-digit PAIRING CODE for the phone app.
echo.
pause
