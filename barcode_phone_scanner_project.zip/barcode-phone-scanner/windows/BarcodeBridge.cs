// Barcode bridge for Windows (receiver side).
// Plain C# 2.0 so the .NET compiler that ships with Windows 7 can build it.
//  - answers UDP discovery broadcasts from the phone app (port 8766)
//  - receives scanned codes over HTTP (port 8765) and "types" them into the
//    window that currently has focus, like a USB barcode reader.
using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;

class BarcodeBridge
{
    const int HttpPort = 8765;
    const int UdpPort = 8766;
    static string Pin;
    static string Dir;
    static readonly object TypeLock = new object();

    // ------------------------------------------------------------ typing ----
    [StructLayout(LayoutKind.Sequential)]
    struct MOUSEINPUT
    {
        public int dx; public int dy; public uint mouseData;
        public uint dwFlags; public uint time; public IntPtr dwExtraInfo;
    }

    [StructLayout(LayoutKind.Sequential)]
    struct KEYBDINPUT
    {
        public ushort wVk; public ushort wScan; public uint dwFlags;
        public uint time; public IntPtr dwExtraInfo;
    }

    [StructLayout(LayoutKind.Explicit)]
    struct INPUTUNION
    {
        [FieldOffset(0)] public MOUSEINPUT mi;
        [FieldOffset(0)] public KEYBDINPUT ki;
    }

    [StructLayout(LayoutKind.Sequential)]
    struct INPUT
    {
        public uint type;
        public INPUTUNION u;
    }

    [DllImport("user32.dll", SetLastError = true)]
    static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);

    [DllImport("user32.dll")]
    static extern short VkKeyScan(char ch);

    [DllImport("user32.dll")]
    static extern uint MapVirtualKey(uint uCode, uint uMapType);

    const uint KEYUP = 0x0002;
    const uint UNICODE = 0x0004;
    const ushort VK_SHIFT = 0x10;
    const ushort VK_RETURN = 0x0D;

    static void Kb(ushort vk, ushort scan, uint flags)
    {
        INPUT[] inp = new INPUT[1];
        inp[0].type = 1;
        inp[0].u.ki.wVk = vk;
        inp[0].u.ki.wScan = scan;
        inp[0].u.ki.dwFlags = flags;
        inp[0].u.ki.time = 0;
        inp[0].u.ki.dwExtraInfo = IntPtr.Zero;
        SendInput(1, inp, Marshal.SizeOf(typeof(INPUT)));
    }

    static void Press(ushort vk)
    {
        ushort scan = (ushort)MapVirtualKey(vk, 0);
        Kb(vk, scan, 0);
        Kb(vk, scan, KEYUP);
    }

    static void TypeChar(char ch)
    {
        int r = VkKeyScan(ch);
        if (r == -1 || (((r >> 8) & 0xFE) != 0))
        {
            // no plain key for this character: send it as a unicode character
            Kb(0, (ushort)ch, UNICODE);
            Kb(0, (ushort)ch, UNICODE | KEYUP);
            return;
        }
        ushort vk = (ushort)(r & 0xFF);
        bool shift = (((r >> 8) & 1) != 0);
        ushort shiftScan = (ushort)MapVirtualKey(VK_SHIFT, 0);
        if (shift) Kb(VK_SHIFT, shiftScan, 0);
        Press(vk);
        if (shift) Kb(VK_SHIFT, shiftScan, KEYUP);
    }

    static void TypeCode(string code, bool enter)
    {
        lock (TypeLock)
        {
            for (int i = 0; i < code.Length; i++)
            {
                TypeChar(code[i]);
                Thread.Sleep(4);
            }
            if (enter)
            {
                Thread.Sleep(20);
                Press(VK_RETURN);
            }
        }
    }

    // ------------------------------------------------------------- http ----
    static void ReplyText(HttpListenerContext ctx, int status, string text)
    {
        try
        {
            byte[] body = Encoding.UTF8.GetBytes(text);
            ctx.Response.StatusCode = status;
            ctx.Response.ContentType = "text/plain; charset=utf-8";
            ctx.Response.ContentLength64 = body.Length;
            ctx.Response.OutputStream.Write(body, 0, body.Length);
        }
        catch (Exception) { }
        try { ctx.Response.OutputStream.Close(); } catch (Exception) { }
    }

    static void Handle(object state)
    {
        HttpListenerContext ctx = (HttpListenerContext)state;
        try
        {
            string path = ctx.Request.Url.AbsolutePath;
            string pin = ctx.Request.QueryString["pin"];
            if (pin == null || pin != Pin)
            {
                Thread.Sleep(800);
                ReplyText(ctx, 403, "forbidden");
                return;
            }

            if (path == "/ping")
            {
                ReplyText(ctx, 200, "ok|" + Environment.MachineName);
                return;
            }

            if (path == "/scan")
            {
                string code = ctx.Request.QueryString["c"];
                bool enter = (ctx.Request.QueryString["e"] != "0");
                if (code == null || code.Length < 1 || code.Length > 80)
                {
                    ReplyText(ctx, 400, "bad code");
                    return;
                }
                for (int i = 0; i < code.Length; i++)
                {
                    if (code[i] < 33 || code[i] > 126)
                    {
                        ReplyText(ctx, 400, "bad code");
                        return;
                    }
                }
                TypeCode(code, enter);
                Console.WriteLine(DateTime.Now.ToString("HH:mm:ss") + "  " + code);
                ReplyText(ctx, 200, "ok");
                return;
            }

            ReplyText(ctx, 404, "not found");
        }
        catch (Exception ex)
        {
            Console.WriteLine("request error: " + ex.Message);
            try { ctx.Response.Abort(); } catch (Exception) { }
        }
    }

    // -------------------------------------------------------- discovery ----
    static void UdpLoop()
    {
        while (true)
        {
            UdpClient udp = null;
            try
            {
                udp = new UdpClient(UdpPort);
                IPEndPoint ep = new IPEndPoint(IPAddress.Any, 0);
                while (true)
                {
                    byte[] data = udp.Receive(ref ep);
                    string s = Encoding.ASCII.GetString(data);
                    if (s.StartsWith("BARCODE_BRIDGE_DISCOVER"))
                    {
                        byte[] reply = Encoding.UTF8.GetBytes(
                            "BARCODE_BRIDGE_HERE|" + HttpPort.ToString() + "|" + Environment.MachineName);
                        udp.Send(reply, reply.Length, ep);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("discovery error: " + ex.Message);
                try { if (udp != null) udp.Close(); } catch (Exception) { }
                Thread.Sleep(2000);
            }
        }
    }

    // ------------------------------------------------------------ setup ----
    static string LoadPin()
    {
        string file = Path.Combine(Dir, "pin.txt");
        try
        {
            if (File.Exists(file))
            {
                string t = File.ReadAllText(file).Trim();
                if (t.Length == 6) return t;
            }
        }
        catch (Exception) { }
        byte[] b = new byte[6];
        RandomNumberGenerator rng = RandomNumberGenerator.Create();
        rng.GetBytes(b);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < b.Length; i++) sb.Append((char)('0' + (b[i] % 10)));
        try { File.WriteAllText(file, sb.ToString()); } catch (Exception) { }
        return sb.ToString();
    }

    static void PrintAddresses()
    {
        try
        {
            IPAddress[] list = Dns.GetHostAddresses(Dns.GetHostName());
            for (int i = 0; i < list.Length; i++)
            {
                IPAddress a = list[i];
                if (a.AddressFamily != AddressFamily.InterNetwork) continue;
                string s = a.ToString();
                if (s.StartsWith("127.") || s.StartsWith("169.254.")) continue;
                Console.WriteLine("   This PC address: " + s);
            }
        }
        catch (Exception) { }
    }

    static int Main(string[] args)
    {
        Dir = AppDomain.CurrentDomain.BaseDirectory;
        Pin = LoadPin();
        Console.Title = "Barcode Bridge";

        HttpListener listener = new HttpListener();
        listener.Prefixes.Add("http://+:" + HttpPort.ToString() + "/");
        try
        {
            listener.Start();
        }
        catch (Exception ex)
        {
            Console.WriteLine("ERROR starting server: " + ex.Message);
            Console.WriteLine("Run install.bat first (it needs administrator permission once).");
            Console.WriteLine("Press Enter to close.");
            Console.ReadLine();
            return 1;
        }

        Thread udp = new Thread(new ThreadStart(UdpLoop));
        udp.IsBackground = true;
        udp.Start();

        Console.WriteLine("============================================================");
        Console.WriteLine(" Barcode bridge is running.");
        Console.WriteLine();
        Console.WriteLine("   PAIRING CODE (enter it once in the phone app):  " + Pin);
        Console.WriteLine();
        PrintAddresses();
        Console.WriteLine();
        Console.WriteLine(" - Phone and PC must be on the same Wi-Fi / hotspot.");
        Console.WriteLine(" - Keep your store software focused, cursor in the barcode box.");
        Console.WriteLine("   Do NOT click on this black window while scanning.");
        Console.WriteLine(" - You can minimize this window. Closing it stops the bridge.");
        Console.WriteLine("============================================================");

        while (true)
        {
            try
            {
                HttpListenerContext ctx = listener.GetContext();
                ThreadPool.QueueUserWorkItem(new WaitCallback(Handle), ctx);
            }
            catch (Exception ex)
            {
                Console.WriteLine("listener error: " + ex.Message);
                Thread.Sleep(500);
            }
        }
    }
}
