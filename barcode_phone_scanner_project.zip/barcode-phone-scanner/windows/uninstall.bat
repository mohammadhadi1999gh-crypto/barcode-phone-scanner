@echo off
title Hnomandan - Uninstall
if "%~1"=="elevated" goto :main
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -ArgumentList 'elevated' -Verb RunAs"
exit /b

:main
taskkill /f /im Hnomandan.exe >nul 2>&1
netsh http delete urlacl url=http://+:8765/ >nul 2>&1
netsh advfirewall firewall delete rule name="Hnomandan TCP" >nul 2>&1
netsh advfirewall firewall delete rule name="Hnomandan UDP" >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -Command "Remove-Item ($env:ProgramData+'\Microsoft\Windows\Start Menu\Programs\Startup\Hnomandan.lnk') -ErrorAction SilentlyContinue; Remove-Item ($env:PUBLIC+'\Desktop\Hnomandan.lnk') -ErrorAction SilentlyContinue"
cd /d "%TEMP%"
rmdir /s /q "C:\Hnomandan"
echo Hnomandan was removed.
pause
