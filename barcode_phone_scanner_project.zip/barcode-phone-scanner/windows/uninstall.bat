@echo off
title Barcode Bridge - Uninstall
if "%~1"=="elevated" goto :main
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -ArgumentList 'elevated' -Verb RunAs"
exit /b

:main
taskkill /f /im BarcodeBridge.exe >nul 2>&1
netsh http delete urlacl url=http://+:8765/ >nul 2>&1
netsh advfirewall firewall delete rule name="Barcode Bridge TCP" >nul 2>&1
netsh advfirewall firewall delete rule name="Barcode Bridge UDP" >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -Command "Remove-Item ($env:ProgramData+'\Microsoft\Windows\Start Menu\Programs\Startup\Barcode Bridge.lnk') -ErrorAction SilentlyContinue; Remove-Item ($env:PUBLIC+'\Desktop\Barcode Bridge.lnk') -ErrorAction SilentlyContinue"
cd /d "%TEMP%"
rmdir /s /q "C:\BarcodeBridge"
echo Barcode Bridge was removed.
pause
