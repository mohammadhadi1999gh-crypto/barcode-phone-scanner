# Barcode Phone Scanner

Use an Android phone camera as a barcode scanner for a Windows PC (Windows 7 or newer).

- `app/` – Android app (Kotlin, CameraX + ML Kit). Finds the PC automatically over Wi-Fi (UDP broadcast), pairs once with a 6-digit code.
- `windows/` – Windows receiver (C#, built on the PC with the compiler that ships with Windows). Types every scanned code into the focused window, followed by Enter, exactly like a USB barcode reader.
- `.github/workflows/build.yml` – builds the APK on GitHub and publishes it under **Releases**.

Ports: TCP 8765 (codes), UDP 8766 (discovery).
